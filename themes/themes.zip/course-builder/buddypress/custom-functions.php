<?php

remove_action( 'bp_init', 'bp_core_wpsignup_redirect' );
remove_action( 'bp_screens', 'bp_core_screen_signup' );
