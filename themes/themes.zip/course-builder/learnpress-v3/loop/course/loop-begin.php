<?php
/**
 * Template for display wrap start of courses list
 *
 * @author  ThimPress
 * @version 3.0.0
 */
?>
<div class="learn-press-courses row">
