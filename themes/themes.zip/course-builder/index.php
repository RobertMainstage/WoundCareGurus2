<?php
/**
 * The template for displaying blog page.
 *
 * @link    https://codex.wordpress.org/Template_Hierarchy
 *
 */

get_template_part( 'archive' );