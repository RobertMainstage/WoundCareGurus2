<?php


thim_customizer()->add_panel(
    array(
        'id'       => 'bp_nouveau_panel',
        'priority' => 100,
        'title'    => esc_html__( 'BuddyPress', 'course-builder' ),
        'icon'     => 'dashicons-businessman',
    )
);