<?php

thim_customizer()->add_panel(
    array(
        'id'       => 'collection',
        'priority' => 47,
        'title'    => esc_html__( 'Collections', 'course-builder' ),
        'icon'     => 'dashicons-category',
    )
);