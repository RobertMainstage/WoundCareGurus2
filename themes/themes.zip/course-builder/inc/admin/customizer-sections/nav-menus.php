<?php
thim_customizer()->add_panel(
	array(
		'id'       => 'nav_menus',
		'priority' => 120,
		'title'    => esc_html__( 'Menus', 'course-builder' ),
		'icon'     => 'dashicons-menu'
	)
);
